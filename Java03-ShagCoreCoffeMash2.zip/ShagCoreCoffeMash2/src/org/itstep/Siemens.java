package org.itstep;

public class Siemens extends Machine {

}
