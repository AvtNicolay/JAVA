package org.itstep;

public class Philips extends Machine {

}
