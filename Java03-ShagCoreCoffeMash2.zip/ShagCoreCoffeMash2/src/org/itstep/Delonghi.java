package org.itstep;

public class Delonghi extends Machine {

}
