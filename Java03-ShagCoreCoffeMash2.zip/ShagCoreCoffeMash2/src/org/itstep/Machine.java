package org.itstep;

import java.util.Scanner;

public class Machine {
	int WaterTankMax;// ���.����� �����.����, ��
	int CoffeeTankMax;// ���.����� ����.����, ��
	int WaterTank;// ������� ����� �����.����,��
	int CoffeeTank;// ������� ����� ����.����, ��

	int CoffeCup;
	int addWater;
	int addCoffee;
	int[] cup = { 0, 0, 0, 0};
	Scanner scan = new Scanner(System.in);

	public int[] Espresso(int[] cup) {
		// CoffeCup - ���-�� ����, ��
		cup[1] = 4 * cup[0];// ���� � �� (��� ������� ���� 1 ����� ����/2 ����� ����)+��� ����������� 2
									// ����� ����
		System.out.print("1 Cup - ");
		System.out.print(cup[0]);
		System.out.print(" ml coffee / ");
		System.out.print(cup[1]);
		System.out.println(" water ml");
		CoffeeTank = cup[2] - cup[0];
		WaterTank = cup[3] - cup[1]; 


		cup[0] = CoffeCup;
		cup[2] = CoffeeTank;
		cup[3] = WaterTank;

		return cup;
	}

	public int[] DoubleEspresso(int[] cup) {
		cup[1] = 4 * cup[0];// ���� � �� (��� ������� ���� 1 ����� ����/2 ����� ����)+��� ����������� 2
		System.out.print("1 Cup - ");
		System.out.print(cup[0]*2);
		System.out.print(" ml coffee / ");
		System.out.print(cup[1]*2);
		System.out.println(" water ml");
		CoffeeTank = cup[2] - cup[0];
		WaterTank = cup[3] - cup[1]; 


		cup[0] = CoffeCup;
		cup[2] = CoffeeTank;
		cup[3] = WaterTank;

		return cup;
	}

	public int[] Americano(int [] cup) {
		cup[1] = 2 * cup[0];// ���� � �� (��� ������� ���� 1 ����� ����/2 ����� ����)+��� ����������� 2
		System.out.print("1 Cup - ");
		System.out.print(cup[0]);
		System.out.print(" ml coffee / ");
		System.out.print(cup[1]);
		System.out.println(" water ml");
		CoffeeTank = cup[2] - cup[0];
		WaterTank = cup[3] - cup[1]; 

		cup[0] = CoffeCup;
		cup[2] = CoffeeTank;
		cup[3] = WaterTank;

		return cup;
	}

	public int CountCoffee(int[] cup, int CoffeeTankMax) {
	
		int CoffeeTank1 = cup[2];
		if (CoffeeTank1 < 0.1 * CoffeeTankMax) {
			while (CoffeeTank1 < 0.1 * CoffeeTankMax) {
				System.out.println("CoffeeOut. Please fill the coffee tank");
				System.out.print("Add Coffee   ");
				addCoffee = scan.nextInt();
				CoffeeTank1 = +addCoffee;
			}
		}
		if (CoffeeTank1 > 0.9 * CoffeeTankMax) {
			System.out.println("Stop. Cofee Tank is full");
			CoffeeTank1 = CoffeeTankMax;
		}

		System.out.println("CoffeeTank=" + CoffeeTank);//����� ����� ������
		cup[2] = CoffeeTank1;
		return cup[2];
	}

	public int CountWater(int[] cup, int WaterTankMax) {
		
		int WaterTank1 = cup[3];
		if (WaterTank1 < 0.1 * WaterTankMax) {
			while (WaterTank1 < 0.1 * WaterTankMax) {
				System.out.println("WatereOut. Please fill the water tank");
				System.out.print("AddWater   ");
				addWater = scan.nextInt();
				WaterTank1 = +addWater;
			}
		}
		if (WaterTank1 > 0.9 * WaterTankMax) {
			System.out.println("Stop. Cofee Tank is full");
			WaterTank1 = WaterTankMax;
		}

		System.out.println("WaterTank=" + WaterTank);//����� ����� ������
		cup[3] = WaterTank1;
		return cup[3];
	}

	public void Information(String[] args) {
		System.out.println("����������� ������ IT Step by Avt");
	}

	public void CoffeStop(String[] args) {
		System.out.println("Bay");
	}

	public void CoffeStart(String[] args) {
		System.out.print("         Push Start - Yes/No   ");
		String button = scan.next();
	
		if (button.equals("N")) {
			System.out.println("*****************************************");
			System.out.println("*             **Good night**            *");
			System.out.println("*****************************************");
			
			 System.exit(0);
		} else {
			System.out.println("*****************************************");
			System.out.println("*               **Hello***              *");
			System.out.println("*                                       *");
			System.out.println("*               **Menu***               *");
			System.out.println("*                                       *");
			System.out.println("* 1. Current Water Level / Coffee Level *");
			System.out.println("* 2.           Espresso                 *");
			System.out.println("* 3.       Double Espresso              *");
			System.out.println("* 4.           Americano                *");
			System.out.println("* 5.   Water Out.Fill the WaterTank     *");
			System.out.println("* 6.  Coffee Out.Fill the CoffeeTank    *");
			System.out.println("* 7.          Information               *");
			System.out.println("* 8.          off Machine               *");
			System.out.println("*                                       *");
			System.out.println("*****************************************");
		}
		
		CoffeeTank = (int) (CoffeeTankMax / 4);
		WaterTank = (int) (WaterTankMax / 4);
		cup[0] = CoffeCup;
		cup[2] = CoffeeTank;
		cup[3] = WaterTank; 
		
		int[] cup1 = {0,0,CoffeeTank,WaterTank};
		
		cup[2] = CountCoffee(cup1, CoffeeTankMax);
		cup[3] = CountWater(cup1, WaterTankMax);
		System.out.print("init.Coffee value - ");
		System.out.print(cup[2]);
		System.out.print(" ml / init.Water value - ");
		System.out.print(cup[3]);
		System.out.println(" ml");
	}
		
	public void menu(String[] args) {
		CoffeStart(args);
		
		System.out.println("*                                       *");
		System.out.println("            Make a choice - ");
		int buttonM = scan.nextInt();
		System.out.println("*                                       *");

		while (buttonM < 8) {
			if (buttonM == 1) {
				cup[2] = CountCoffee(cup, CoffeeTankMax);
				cup[3] = CountWater(cup, WaterTankMax);
				System.out.print("Current Coffeer Level - ");
				System.out.print(cup[2]);
				System.out.print(" ml / Current Water Level - ");
				System.out.print(cup[3]);
				System.out.println(" ml");

				System.out.println("*                                       *");
				System.out.println("            Make a choice - ");
				buttonM = scan.nextInt();
			}

			if (buttonM == 2) {
				System.out.println("*               Espresso                *");
				cup = Espresso(cup);

				CountCoffee(cup, CoffeeTankMax);
				CountWater(cup, WaterTankMax);

				System.out.println("            Make a choice - ");
				buttonM = scan.nextInt();
			}

			if (buttonM == 3) {
				System.out.println("*               DoubleEspresso                *");
				cup = DoubleEspresso(cup);

				CountCoffee(cup, CoffeeTankMax);
				CountWater(cup, WaterTankMax);

				System.out.println("            Make a choice - ");
				buttonM = scan.nextInt();
			}

			if (buttonM == 4) {

				System.out.println("*               Americano               *");
				cup = Americano(cup);

				CountCoffee(cup, CoffeeTankMax);
				CountWater(cup, WaterTankMax);

				System.out.println("            Make a choice - ");
				buttonM = scan.nextInt();
			}

			if (buttonM == 5) {
				System.out.print("Current Volum Water - ");
				int WaterTank2 = CountWater(cup, WaterTankMax);
				System.out.print(WaterTank2);
				System.out.print(" ml");

				System.out.println("            Make a choice - ");
				buttonM = scan.nextInt();

			}

			if (buttonM == 6) {
				System.out.print("Current Volum Coffee - ");
				int CoffeeTank2 = CountCoffee(cup, CoffeeTankMax);
				System.out.print(CoffeeTank2);
				System.out.println(" ml");

				System.out.println("            Make a choice - ");
				buttonM = scan.nextInt();

			}

			if (buttonM == 7) {
				Information(args);

				System.out.println("            Make a choice - ");
				buttonM = scan.nextInt();
			}

			if (buttonM >= 8) {
				CoffeStop(args);
				return;
			}
		}
return;
	}
}